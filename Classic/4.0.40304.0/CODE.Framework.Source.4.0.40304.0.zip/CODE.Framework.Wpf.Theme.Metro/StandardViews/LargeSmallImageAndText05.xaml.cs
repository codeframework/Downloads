﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeSmallImageAndText05.xaml
    /// </summary>
    public partial class LargeSmallImageAndText05 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeSmallImageAndText05"/> class.
        /// </summary>
        public LargeSmallImageAndText05()
        {
            InitializeComponent();
        }
    }
}

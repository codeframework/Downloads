﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText08.xaml
    /// </summary>
    public partial class LargeText08 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText08"/> class.
        /// </summary>
        public LargeText08()
        {
            InitializeComponent();
        }
    }
}

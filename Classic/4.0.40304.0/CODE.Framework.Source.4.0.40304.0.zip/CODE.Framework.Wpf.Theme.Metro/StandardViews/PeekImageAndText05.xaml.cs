﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for PeekImageAndText05.xaml
    /// </summary>
    public partial class PeekImageAndText05 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PeekImageAndText05"/> class.
        /// </summary>
        public PeekImageAndText05()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for DataSmall03.xaml
    /// </summary>
    public partial class DataSmall03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataSmall03"/> class.
        /// </summary>
        public DataSmall03()
        {
            InitializeComponent();
        }
    }
}

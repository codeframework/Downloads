﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageAndText06.xaml
    /// </summary>
    public partial class LargePeekImageAndText06 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageAndText06"/> class.
        /// </summary>
        public LargePeekImageAndText06()
        {
            InitializeComponent();
        }
    }
}

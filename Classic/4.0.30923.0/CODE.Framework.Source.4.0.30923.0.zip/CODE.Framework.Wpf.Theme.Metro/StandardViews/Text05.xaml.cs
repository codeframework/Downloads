﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for Text05.xaml
    /// </summary>
    public partial class Text05 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Text05"/> class.
        /// </summary>
        public Text05()
        {
            InitializeComponent();
        }
    }
}

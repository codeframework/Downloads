﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageCollection03.xaml
    /// </summary>
    public partial class LargePeekImageCollection03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageCollection03"/> class.
        /// </summary>
        public LargePeekImageCollection03()
        {
            InitializeComponent();
        }
    }
}

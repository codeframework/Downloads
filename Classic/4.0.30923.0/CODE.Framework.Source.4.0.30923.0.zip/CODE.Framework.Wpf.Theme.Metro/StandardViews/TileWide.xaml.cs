﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileWide.xaml
    /// </summary>
    public partial class TileWide : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileWide"/> class.
        /// </summary>
        public TileWide()
        {
            InitializeComponent();
        }
    }
}

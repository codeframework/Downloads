﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeBlockAndTexct02.xaml
    /// </summary>
    public partial class LargeBlockAndText02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeBlockAndText02"/> class.
        /// </summary>
        public LargeBlockAndText02()
        {
            InitializeComponent();
        }
    }
}

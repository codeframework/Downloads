﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using CODE.Framework.Core.Utilities.Extensions;

namespace CODE.Framework.Wpf.Mvvm.Tools
{
    /// <summary>
    /// Interaction logic for ViewVisualizer.xaml
    /// </summary>
    public partial class ViewVisualizer : Window, IViewHandler, INotifyPropertyChanged
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ViewVisualizer"/> class.
        /// </summary>
        public ViewVisualizer()
        {
            DataContext = this;
            Views = new ObservableCollection<ViewVisualizerItem>();
            InitializeComponent();
        }

        /// <summary>
        /// Gets or sets the views.
        /// </summary>
        /// <value>
        /// The views.
        /// </value>
        public ObservableCollection<ViewVisualizerItem> Views { get; set; }

        private ViewVisualizerItem _currentItem;

        /// <summary>
        /// Currently selected view
        /// </summary>
        public ViewVisualizerItem CurrentItem
        {
            get { return _currentItem; }
            set
            {
                _currentItem = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("CurrentItem"));
            }
        }

        /// <summary>
        /// This method is invoked when a view is opened
        /// </summary>
        /// <param name="context">Request context (contains information about the view)</param>
        /// <returns>True if handled successfully</returns>
        public bool OpenView(RequestContext context)
        {
            if (context.Result is StatusMessageResult) return false;
            if (context.Result is NotificationMessageResult) return false;

            var viewResult = context.Result as ViewResult;
            if (viewResult != null && !viewResult.IsPartial)
            {
                var viewItem = new ViewVisualizerItem
                                   {
                                       ViewSource = viewResult.ViewSource,
                                       ViewObject = viewResult.View,
                                       View = new VisualBrush(viewResult.View) {Stretch = Stretch.Uniform},
                                       Model = viewResult.Model,
                                       Controller = context.ProcessingController,
                                       Title = viewResult.ViewTitle
                                   };
                if (context.RouteData.Data.ContainsKey("action")) viewItem.Action = context.RouteData.Data["action"].ToString();
                if (context.RouteData.Data.ContainsKey("Action")) viewItem.Action = context.RouteData.Data["Action"].ToString();
                Views.Add(viewItem);
                return true;
            }
            return false;
        }

        /// <summary>
        /// This method is invoked when a view that is associated with a certain model should be closed
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool CloseViewForModel(object model)
        {
            foreach (var view in Views)
                if (view.Model != null && view.Model == model)
                {
                    Views.Remove(view);
                    return true;
                }
            return false;
        }

        /// <summary>
        /// This method closes all currently open views
        /// </summary>
        /// <returns>True if the handler successfully closed all views. False if it didn't close all views or generally does not handle view closing</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public bool CloseAllViews()
        {
            // This handler does not handle view closing
            return false;
        }

        /// <summary>
        /// This method is used to retrieve a view associated with the specified model
        /// </summary>
        /// <param name="model">Model</param>
        /// <returns>
        /// Document if found (null otherwise)
        /// </returns>
        public object GetViewForModel(object model)
        {
            return null;
        }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Handles the MouseDoubleClick event of the ScaleSlider control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Input.MouseButtonEventArgs"/> instance containing the event data.</param>
        private void ScaleSlider_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            ScaleSlider.Value = 1;
        }

        /// <summary>
        /// Handles the Checked event of the CheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (ShadowCheck.IsChecked == true) ViewRectangle.Effect = new DropShadowEffect();
            else ViewRectangle.Effect = null;
        }

        /// <summary>
        /// Handles the SelectionChanged event of the ComboBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Controls.SelectionChangedEventArgs"/> instance containing the event data.</param>
        private void ComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            switch (ColorDropDown.SelectedIndex)
            {
                case 0:
                    ContentScroll.Background = null;
                    break;
                case 1:
                    ContentScroll.Background = Brushes.White;
                    break;
                case 2:
                    ContentScroll.Background = Brushes.Black;
                    break;
                case 3:
                    ContentScroll.Background = Brushes.Gray;
                    break;
                case 4:
                    ContentScroll.Background = Brushes.CornflowerBlue;
                    break;
            }
        }

        /// <summary>
        /// Handles the SelectedItemChanged event of the TreeView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="object"/> instance containing the event data.</param>
        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue != null)
                CurrentItem.SelectedElement = e.NewValue as UIElementViewModel;
            else if (CurrentItem != null && CurrentItem.Elements != null && CurrentItem.Elements.Count > 0)
                CurrentItem.SelectedElement = CurrentItem.Elements[0];
        }
    }

    /// <summary>
    /// Document visualizer item
    /// </summary>
    public class ViewVisualizerItem : INotifyPropertyChanged
    {
        /// <summary>
        /// Document description
        /// </summary>
        public string ViewSource { get; set; }

        /// <summary>
        /// Bindable text for the view information
        /// </summary>
        public string ViewSourceText
        {
            get
            {
                string sourceText = ViewSource;
                if (string.IsNullOrEmpty(sourceText)) sourceText = "n/a";
                return "Document: " + sourceText;
            }
        }

        /// <summary>
        /// Visual brush representing the view
        /// </summary>
        public VisualBrush View { get; set; }

        /// <summary>
        /// The actual view
        /// </summary>
        public FrameworkElement ViewObject { get; set; }

        /// <summary>
        /// Model associated with the view
        /// </summary>
        public object Model
        {
            get { return _model; }
            set
            {
                _model = value;
                ModelClass = _model != null ? _model.GetType().ToString() : "n/a";
            }
        }

        private object _model;

        /// <summary>
        /// Class used for the view model
        /// </summary>
        public string ModelClass { get; private set; }

        /// <summary>
        /// Bindable text for the view information
        /// </summary>
        public string ModelText
        {
            get { return "Model: " + ModelClass; }
        }

        /// <summary>
        /// Model associated with the view
        /// </summary>
        public object Controller
        {
            get { return _controller; }
            set
            {
                _controller = value;
                ControllerClass = _controller != null ? _controller.GetType().ToString() : "Unknown";
            }
        }

        private object _controller;

        /// <summary>
        /// Class used for the controller
        /// </summary>
        public string ControllerClass { get; private set; }

        /// <summary>
        /// Bindable text for the controller information
        /// </summary>
        public string ControllerText
        {
            get
            {
                if (string.IsNullOrEmpty(ControllerClass)) return "Controller: n/a";
                string text = "Controller: " + ControllerClass;
                if (!string.IsNullOrEmpty(Action)) text += "::" + Action + "(...)";
                return text;
            }
        }

        /// <summary>
        /// Controller Action
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// Document title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// List of available resources for a view
        /// </summary>
        public List<ResourceItem> AvailableResources
        {
            get
            {
                var result = new List<ResourceItem>();
                if (ViewObject != null && ViewObject.Resources != null)
                    foreach (var dictionary in ViewObject.Resources.MergedDictionaries)
                        result.Add(new ResourceItem {Name = dictionary.Source.ToStringSafe()});
                return result;
            }
        }

        /// <summary>
        /// Inspects a specific element and adds it to the list
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="collection">The collection.</param>
        /// <param name="rootView">The root view.</param>
        private static void AddElement(UIElement element, ObservableCollection<UIElementViewModel> collection, UIElement rootView)
        {
            var parts1 = element.ToString().Split(' ');
            var parts2 = parts1[0].Split('.');
            var elementName = parts2[parts2.Length - 1].Replace(":", "");
            string content = "";
            if (parts1.Length > 1) content = parts1[1];

            var newElement = new UIElementViewModel(rootView)
                                 {
                                     Name = elementName,
                                     Content = content,
                                     Type = element.GetType().ToString(),
                                     UIElement = element
                                 };
            var contentControl = element as ContentControl;
            if (contentControl != null)
            {
                if (contentControl.Content != null && contentControl.Content is UIElement)
                    AddElement(contentControl.Content as UIElement, newElement.Elements, rootView);
            }
            else
            {
                var childControl = element as Panel;
                if (childControl != null)
                    foreach (var child in childControl.Children)
                    {
                        if (child != null && child is UIElement)
                            AddElement(child as UIElement, newElement.Elements, rootView);
                    }
                else
                {
                    var itemsControl = element as ItemsControl;
                    if (itemsControl != null)
                        foreach (var item in itemsControl.Items)
                            if (item != null && item is UIElement)
                                AddElement(item as UIElement, newElement.Elements, rootView);
                }
            }
            collection.Add(newElement);
        }

        /// <summary>Hierarchical list of UI elements</summary>
        public ObservableCollection<UIElementViewModel> Elements
        {
            get
            {
                var elements = new ObservableCollection<UIElementViewModel>();
                if (ViewObject != null)
                    AddElement(ViewObject, elements, ViewObject);
                return elements;
            }
        }

        private UIElementViewModel _selectedElement;

        /// <summary>Gets or sets the selected element from the view hierarchy tree.</summary>
        public UIElementViewModel SelectedElement
        {
            get { return _selectedElement; }
            set
            {
                _selectedElement = value;
                NotifyChanged("SelectedElement");
            }
        }

        /// <summary>
        /// Current e
        /// </summary>
        public FrameworkElement CurrentElement { get; set; }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyChanged(string propertyName = "")
        {
            try
            {
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
            catch (Exception)
            {
            }
        }
    }

    /// <summary>Resource item in visualizer</summary>
    public class ResourceItem
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }
    }

    /// <summary>Document model for individual UI elements</summary>
    public class UIElementViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UIElementViewModel"/> class.
        /// </summary>
        public UIElementViewModel(UIElement rootView)
        {
            CurrentView = rootView;
            Elements = new ObservableCollection<UIElementViewModel>();
        }

        /// <summary>Object or instance name</summary>
        public string Name { get; set; }

        /// <summary>Additional information about the object, such as the value of a textbox, or the caption of a label</summary>
        public string Content { get; set; }

        /// <summary>Display specific version of the content</summary>
        public string ContentDisplay
        {
            get
            {
                if (string.IsNullOrEmpty(Content)) return string.Empty;
                return " (" + Content.Trim() + ")";
            }
        }

        /// <summary>Type of the UI element (class)</summary>
        public string Type { get; set; }

        /// <summary>Actual UI element</summary>
        public UIElement UIElement { get; set; }

        /// <summary>Hierarchical list of UI elements</summary>
        public ObservableCollection<UIElementViewModel> Elements { get; set; }

        /// <summary>Actual visual of the UI element this item represents</summary>
        public VisualBrush UIElementVisual
        {
            get { return new VisualBrush(UIElement); }
        }

        /// <summary>List of associated resource dictionaries</summary>
        public ObservableCollection<ResourceDictionaryViewModel> ResourceDictionaries
        {
            get
            {
                var dictionaries = new ObservableCollection<ResourceDictionaryViewModel>();

                var appDictionaries = new ResourceDictionaryViewModel {Source = "Application"};
                dictionaries.Add(appDictionaries);
                foreach (var dictionary in Application.Current.Resources.MergedDictionaries)
                    AddDictionaries(appDictionaries.ResourceDictionaries, dictionary);

                var viewDictionaries = new ResourceDictionaryViewModel {Source = "Document"};
                dictionaries.Add(viewDictionaries);
                var currentElement2 = CurrentView as FrameworkElement;
                if (currentElement2 != null)
                    foreach (var dictionary in currentElement2.Resources.MergedDictionaries)
                        AddDictionaries(viewDictionaries.ResourceDictionaries, dictionary);

                if (CurrentView != UIElement)
                {
                    var elementDictionaries = new ResourceDictionaryViewModel {Source = "Element"};
                    dictionaries.Add(elementDictionaries);
                    var currentElement = UIElement as FrameworkElement;
                    if (currentElement != null)
                        foreach (var dictionary in currentElement.Resources.MergedDictionaries)
                            AddDictionaries(elementDictionaries.ResourceDictionaries, dictionary);
                }

                return dictionaries;
            }
        }

        /// <summary>Collection of styles applying to the current control</summary>
        public ObservableCollection<ControlStyleViewModel> ControlStyles
        {
            get
            {
                var styles = new ObservableCollection<ControlStyleViewModel>();

                var currentElement = UIElement as FrameworkElement;
                if (currentElement != null && currentElement.Style != null)
                    AddStyleInformation(styles, currentElement, currentElement.Style);

                // We are now checking to see if any setters are overridden in inherited styles
                for (int counter = 0; counter < styles.Count; counter++ )
                {
                    var style = styles[counter];
                    foreach (var setter in style.ControlStyles)
                        for (int counter2 = counter + 1; counter2 < styles.Count; counter2++)
                            foreach (var setter2 in styles[counter2].ControlStyles)
                                if (setter2.Property == setter.Property)
                                {
                                    setter.IsOverridden = true;
                                    break;
                                }
                }
                
                return styles;
            }
        }

        /// <summary>
        /// Adds style information to the provided colection
        /// </summary>
        /// <param name="styles">The styles.</param>
        /// <param name="currentElement">The current element.</param>
        /// <param name="style">The style.</param>
        /// <param name="inheritedStyle">if set to <c>true</c> [inherited style].</param>
        private static void AddStyleInformation(ObservableCollection<ControlStyleViewModel> styles, FrameworkElement currentElement, Style style, bool inheritedStyle = false)
        {
            var appliedStyle = new ControlStyleViewModel
                                   {
                                       TargetType = style.TargetType.ToString(),
                                       Style = style,
                                       IsInheritedStyle = inheritedStyle
                                   };
            styles.Insert(0, appliedStyle);

            foreach (Setter setter in style.Setters)
            {
                var newSetter = new ControlStyleViewModel { Property = setter.Property.Name, };
                if (setter.Value == null) newSetter.Value = "{x:Null}";
                else
                {
                    var extension = setter.Value as DynamicResourceExtension;
                    if (extension != null)
                        newSetter.Value = "{DynamicResource " + extension.ResourceKey.ToString() + "}";
                    else
                        newSetter.Value = setter.Value.ToString();
                }
                appliedStyle.ControlStyles.Add(newSetter);
            }

            if (!inheritedStyle)
            {
                var local = currentElement.ReadLocalValue(FrameworkElement.StyleProperty);
                if (local != null)
                {
                    var localType = local.GetType();
                    if (localType.Name == "ResourceReferenceExpression")
                    {
                        var resourceKeyProperty = localType.GetProperty("ResourceKey");
                        if (resourceKeyProperty != null)
                            appliedStyle.Key = resourceKeyProperty.GetValue(local, null) as string;
                    }
                }
            }

            if (style.BasedOn != null)
                AddStyleInformation(styles, currentElement, style.BasedOn, true);
        }

        /// <summary>
        /// Document associated with this item (root view)
        /// </summary>
        public UIElement CurrentView { get; set; }

        /// <summary>Recursively populates resource dictionaries</summary>
        /// <param name="collection">The collection.</param>
        /// <param name="resourceDictionary">The resource dictionary.</param>
        private static void AddDictionaries(ObservableCollection<ResourceDictionaryViewModel> collection, ResourceDictionary resourceDictionary)
        {
            var model = new ResourceDictionaryViewModel
                            {
                                Source = resourceDictionary.Source.ToString(),
                                ResourceDictionary = resourceDictionary
                            };
            collection.Add(model);

            foreach (var dictionary in resourceDictionary.MergedDictionaries)
                AddDictionaries(model.ResourceDictionaries, dictionary);
        }
    }

    /// <summary>
    /// Information about availble view models
    /// </summary>
    public class ResourceDictionaryViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceDictionaryViewModel"/> class.
        /// </summary>
        public ResourceDictionaryViewModel()
        {
            ResourceDictionaries = new ObservableCollection<ResourceDictionaryViewModel>();
        }

        /// <summary>
        /// Source from which the resource dictionary was loaded
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Link to the actual resource dictionary
        /// </summary>
        public ResourceDictionary ResourceDictionary { get; set; }

        /// <summary>
        /// Linked resource dictionaries
        /// </summary>
        public ObservableCollection<ResourceDictionaryViewModel> ResourceDictionaries { get; set; }
    }

    /// <summary>
    /// Informatoin about available control styles
    /// </summary>
    public class ControlStyleViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ControlStyleViewModel"/> class.
        /// </summary>
        public ControlStyleViewModel()
        {
            ControlStyles = new ObservableCollection<ControlStyleViewModel>();
        }
        /// <summary>Property name that is to be set</summary>
        public string Property { get; set; }
        /// <summary>Property value that is to be set</summary>
        public string Value { get; set; }
        /// <summary>Style key</summary>
        public string Key { get; set; }
        /// <summary>Target type</summary>
        public string TargetType { get; set; }
        /// <summary>Display name for key or target type</summary>
        public string DisplayName
        {
            get
            {
                if (!string.IsNullOrEmpty(Property)) return Property + " = " + Value;
                if (IsInheritedStyle)
                    return "[Inherited]";
                if (string.IsNullOrEmpty(Key)) return "Implicit for type [" + TargetType + "]";
                return "Key: " + Key + " for type [" + TargetType + "]";
            }
        }

        /// <summary>Indicates whether this style is based on the prior style</summary>
        public bool IsInheritedStyle { get; set; }

        /// <summary>Actual style</summary>
        public Style Style { get; set; }

        /// <summary>Control style members</summary>
        public ObservableCollection<ControlStyleViewModel> ControlStyles { get; set; }

        /// <summary>Indicates whether the style is overridden by an inherited style</summary>
        public bool IsOverridden { get; set; }

        /// <summary>
        /// Gets the text decorations.
        /// </summary>
        public object TextDecorations
        {
            get
            {
                var converter = new TextDecorationCollectionConverter();
                if (IsOverridden)
                    return converter.ConvertFrom("Strikethrough");
                return converter.ConvertFrom("None");
            }
        }
    }
}

﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace CODE.Framework.Wpf.Utilities
{
    /// <summary>This class provides helpful features for focus management</summary>
    public static class FocusHelper
    {
        /// <summary>
        /// Sets the focus to the specified control(s) but after a slight delay to allow the calling method to finish before the focus is moved (by routing through a background thread and the message pump)
        /// </summary>
        /// <param name="focusElement1">The element to set the focus to.</param>
        /// <param name="focusElement2">An (optional) next element to set the focus to (typically a parent of the prior element).</param>
        /// <param name="focusElement3">An (optional) next element to set the focus to (typically a parent of the prior element).</param>
        /// <param name="focusElement4">An (optional) next element to set the focus to (typically a parent of the prior element).</param>
        /// <param name="delay">The delay in milliseconds before the focus is moved (100ms is the default).</param>
        public static void FocusDelayed(FrameworkElement focusElement1, FrameworkElement focusElement2 = null, FrameworkElement focusElement3 = null, FrameworkElement focusElement4 = null, int delay = 100)
        {
            var action = new Action<FrameworkElement, FrameworkElement, FrameworkElement, FrameworkElement, int>(FocusDelayed2);
            action.BeginInvoke(focusElement1, focusElement2, focusElement3, focusElement4, delay, null, null);
        }

        private static void FocusDelayed2(FrameworkElement focusElement1, FrameworkElement focusElement2, FrameworkElement focusElement3, FrameworkElement focusElement4, int delay)
        {
            Thread.Sleep(delay);
            var action = new Action<FrameworkElement, FrameworkElement, FrameworkElement, FrameworkElement, int>(FocusDelayed3);
            Application.Current.Dispatcher.BeginInvoke(action, DispatcherPriority.ApplicationIdle, new object[] {focusElement1, focusElement2, focusElement3, focusElement4, delay});
        }

        private static void FocusDelayed3(FrameworkElement focusElement1, FrameworkElement focusElement2, FrameworkElement focusElement3, FrameworkElement focusElement4, int delay)
        {
            MoveFocusIfPossible(focusElement1, delay);
            MoveFocusIfPossible(focusElement2, delay);
            MoveFocusIfPossible(focusElement3, delay);
            MoveFocusIfPossible(focusElement4, delay);
        }

        private static void MoveFocusIfPossible(FrameworkElement element, int delay)
        {
            if (element != null)
                if (element.IsVisible)
                    element.Focus();
                else
                    // Not there yet... we can try again
                    FocusDelayed(element, delay: delay);
        }
    }
}

﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// Information specific to this project/assembly
[assembly: AssemblyTitle("CODE Framework - WPF Workplace Theme")]
[assembly: AssemblyDescription("CODE Framework WPF Workplace Theme")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

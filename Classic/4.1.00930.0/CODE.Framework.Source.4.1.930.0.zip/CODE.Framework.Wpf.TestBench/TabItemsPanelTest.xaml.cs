﻿namespace CODE.Framework.Wpf.TestBench
{
    /// <summary>
    /// Interaction logic for TabItemsPanelTest.xaml
    /// </summary>
    public partial class TabItemsPanelTest
    {
        public TabItemsPanelTest()
        {
            InitializeComponent();
        }
    }
}

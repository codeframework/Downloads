﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText02.xaml
    /// </summary>
    public partial class LargeText02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText02"/> class.
        /// </summary>
        public LargeText02()
        {
            InitializeComponent();
        }
    }
}

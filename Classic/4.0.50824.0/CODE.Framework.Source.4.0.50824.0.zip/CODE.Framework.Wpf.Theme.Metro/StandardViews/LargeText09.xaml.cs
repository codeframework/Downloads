﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText09.xaml
    /// </summary>
    public partial class LargeText09 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText09"/> class.
        /// </summary>
        public LargeText09()
        {
            InitializeComponent();
        }
    }
}

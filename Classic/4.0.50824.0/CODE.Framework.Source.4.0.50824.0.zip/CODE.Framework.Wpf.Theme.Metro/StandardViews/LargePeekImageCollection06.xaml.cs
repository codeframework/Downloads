﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageCollection06.xaml
    /// </summary>
    public partial class LargePeekImageCollection06 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageCollection06"/> class.
        /// </summary>
        public LargePeekImageCollection06()
        {
            InitializeComponent();
        }
    }
}

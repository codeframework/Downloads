﻿using CODE.Framework.Wpf.Mvvm;

namespace CODE.Framework.Wpf.Theme.Battleship.Controls
{
    /// <summary>
    /// Special menu object used in Battleship-style applications
    /// </summary>
    public class BattleshipMenu : ViewActionMenu
    {
    }
}

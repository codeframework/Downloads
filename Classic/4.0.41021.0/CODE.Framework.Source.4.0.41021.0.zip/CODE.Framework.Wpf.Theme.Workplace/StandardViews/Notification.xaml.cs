﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Workplace.StandardViews
{
    /// <summary>
    /// Interaction logic for Notification.xaml
    /// </summary>
    public partial class Notification : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Notification" /> class.
        /// </summary>
        public Notification()
        {
            InitializeComponent();
        }
    }
}

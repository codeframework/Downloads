﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageAndText04.xaml
    /// </summary>
    public partial class LargePeekImageAndText04 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageAndText04"/> class.
        /// </summary>
        public LargePeekImageAndText04()
        {
            InitializeComponent();
        }
    }
}

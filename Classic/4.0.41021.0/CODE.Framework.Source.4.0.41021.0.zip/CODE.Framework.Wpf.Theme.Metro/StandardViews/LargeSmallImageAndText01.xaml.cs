﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeSmallImageAndText01.xaml
    /// </summary>
    public partial class LargeSmallImageAndText01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeSmallImageAndText01"/> class.
        /// </summary>
        public LargeSmallImageAndText01()
        {
            InitializeComponent();
        }
    }
}

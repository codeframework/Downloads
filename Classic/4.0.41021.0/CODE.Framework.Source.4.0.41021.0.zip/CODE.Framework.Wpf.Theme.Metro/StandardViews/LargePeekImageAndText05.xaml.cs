﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageAndText05.xaml
    /// </summary>
    public partial class LargePeekImageAndText05 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageAndText05"/> class.
        /// </summary>
        public LargePeekImageAndText05()
        {
            InitializeComponent();
        }
    }
}

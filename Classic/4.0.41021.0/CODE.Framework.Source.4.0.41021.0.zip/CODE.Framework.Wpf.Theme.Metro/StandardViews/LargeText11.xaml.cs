﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText11.xaml
    /// </summary>
    public partial class LargeText11 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText11"/> class.
        /// </summary>
        public LargeText11()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows;
using System.Windows.Controls;

namespace CODE.Framework.Wpf.Mvvm
{
    /// <summary>
    /// Special tab control used to host views (typically normal views in the shell)
    /// </summary>
    /// <remarks>Designed for internal use only</remarks>
    public class ViewHostTabControl : TabControl
    {
        /// <summary>Defines whether tab headers shall be displayed</summary>
        /// <remarks>It is up to each theme to respect this property</remarks>
        public bool ShowHeaders
        {
            get { return (bool)GetValue(ShowHeadersProperty); }
            set { SetValue(ShowHeadersProperty, value); }
        }
        /// <summary>Defines whether tab headers shall be displayed</summary>
        /// <remarks>It is up to each theme to respect this property</remarks>
        public static readonly DependencyProperty ShowHeadersProperty = DependencyProperty.Register("ShowHeaders", typeof(bool), typeof(ViewHostTabControl), new PropertyMetadata(true));
    }

}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for PeekImageAndText02.xaml
    /// </summary>
    public partial class PeekImageAndText02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PeekImageAndText02"/> class.
        /// </summary>
        public PeekImageAndText02()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for Text03.xaml
    /// </summary>
    public partial class Text03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Text03"/> class.
        /// </summary>
        public Text03()
        {
            InitializeComponent();
        }
    }
}

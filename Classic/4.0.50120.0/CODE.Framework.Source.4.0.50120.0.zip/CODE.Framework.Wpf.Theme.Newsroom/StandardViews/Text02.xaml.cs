﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for Text02.xaml
    /// </summary>
    public partial class Text02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Text02"/> class.
        /// </summary>
        public Text02()
        {
            InitializeComponent();
        }
    }
}

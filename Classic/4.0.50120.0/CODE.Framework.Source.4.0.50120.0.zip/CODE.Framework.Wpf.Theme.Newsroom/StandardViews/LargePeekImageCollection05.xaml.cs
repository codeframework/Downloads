﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageCollection05.xaml
    /// </summary>
    public partial class LargePeekImageCollection05 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageCollection05"/> class.
        /// </summary>
        public LargePeekImageCollection05()
        {
            InitializeComponent();
        }
    }
}

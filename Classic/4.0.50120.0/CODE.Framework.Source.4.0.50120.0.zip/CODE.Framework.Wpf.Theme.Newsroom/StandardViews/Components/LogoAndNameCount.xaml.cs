﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews.Components
{
    /// <summary>
    /// Interaction logic for LogoNameAndCount.xaml
    /// </summary>
    public partial class LogoNameAndCount : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogoNameAndCount"/> class.
        /// </summary>
        public LogoNameAndCount()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for Text01.xaml
    /// </summary>
    public partial class Text01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Text01"/> class.
        /// </summary>
        public Text01()
        {
            InitializeComponent();
        }
    }
}

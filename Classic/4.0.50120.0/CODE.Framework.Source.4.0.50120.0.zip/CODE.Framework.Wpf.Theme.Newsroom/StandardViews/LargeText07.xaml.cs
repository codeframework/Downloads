﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText07.xaml
    /// </summary>
    public partial class LargeText07 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText07"/> class.
        /// </summary>
        public LargeText07()
        {
            InitializeComponent();
        }
    }
}

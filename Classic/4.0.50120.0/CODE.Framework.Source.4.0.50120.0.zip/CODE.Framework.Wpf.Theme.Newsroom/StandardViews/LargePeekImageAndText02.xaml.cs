﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargePeekImageAndText02.xaml
    /// </summary>
    public partial class LargePeekImageAndText02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargePeekImageAndText02"/> class.
        /// </summary>
        public LargePeekImageAndText02()
        {
            InitializeComponent();
        }
    }
}

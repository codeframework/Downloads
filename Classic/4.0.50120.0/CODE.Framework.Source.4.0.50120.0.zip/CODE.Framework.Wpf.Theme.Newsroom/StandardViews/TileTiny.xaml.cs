﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Templates for tiny tiles
    /// </summary>
    public partial class TileTiny : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileTiny"/> class.
        /// </summary>
        public TileTiny()
        {
            InitializeComponent();
        }
    }
}

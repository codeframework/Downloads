﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for Data01.xaml
    /// </summary>
    public partial class Data01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Data01"/> class.
        /// </summary>
        public Data01()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for DataSmall01.xaml
    /// </summary>
    public partial class DataSmall01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataSmall01"/> class.
        /// </summary>
        public DataSmall01()
        {
            InitializeComponent();
        }
    }
}

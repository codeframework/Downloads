﻿using System.Windows.Controls;
using CODE.Framework.Wpf.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for DataRowAndImage01.xaml
    /// </summary>
    public partial class DataRowAndImage01 : GridEx
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataRowAndImage01"/> class.
        /// </summary>
        public DataRowAndImage01()
        {
            InitializeComponent();
        }
    }
}

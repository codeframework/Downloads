﻿using System.Windows;
using CODE.Framework.Wpf.Mvvm;

namespace CODE.Framework.Wpf.TestBench
{
    /// <summary>
    /// Interaction logic for ViewActionItemsControlTest.xaml
    /// </summary>
    public partial class ViewActionItemsControlTest : Window
    {
        public ViewActionItemsControlTest()
        {
            InitializeComponent();
            DataContext = new ViewActionItemsControlTestViewModel();
        }
    }

    public class ViewActionItemsControlTestViewModel : ViewModel
    {
        public ViewActionItemsControlTestViewModel()
        {
            Actions.Add(new ViewAction("Action #1", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save"));
            Actions.Add(new ViewAction("Action #2", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save"));
            Actions.Add(new ViewAction("Action #5", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save") { Significance = ViewActionSignificance.BelowNormal });
            Actions.Add(new ViewAction("Action #5", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save") { Significance = ViewActionSignificance.BelowNormal });
            Actions.Add(new ViewAction("Action #5", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save") { Significance = ViewActionSignificance.BelowNormal });
            Actions.Add(new ViewAction("Action #3", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save") { Significance = ViewActionSignificance.AboveNormal });
            Actions.Add(new ViewAction("Action #4", brushResourceKey: "CODE.Framework-Icon-Save", logoBrushResourceKey: "CODE.Framework-Icon-Save") { Significance = ViewActionSignificance.Highest });
        }
    }
}

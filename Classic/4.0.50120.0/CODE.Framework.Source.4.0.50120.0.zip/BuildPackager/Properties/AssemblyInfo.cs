﻿using System.Reflection;

[assembly: AssemblyTitle("BuildPackager")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

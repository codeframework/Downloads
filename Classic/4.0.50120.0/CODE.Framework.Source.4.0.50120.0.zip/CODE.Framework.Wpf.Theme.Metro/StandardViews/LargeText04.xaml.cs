﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText04.xaml
    /// </summary>
    public partial class LargeText04 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText04"/> class.
        /// </summary>
        public LargeText04()
        {
            InitializeComponent();
        }
    }
}

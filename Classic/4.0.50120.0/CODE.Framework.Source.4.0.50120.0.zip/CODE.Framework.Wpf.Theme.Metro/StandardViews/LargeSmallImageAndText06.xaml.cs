﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeSmallImageAndText06.xaml
    /// </summary>
    public partial class LargeSmallImageAndText06 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeSmallImageAndText06"/> class.
        /// </summary>
        public LargeSmallImageAndText06()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows;
using System.Windows.Controls;
using CODE.Framework.Wpf.Mvvm;

namespace CODE.Framework.Wpf.Theme.Metro.Classes
{
    /// <summary>
    /// Selects an appropriate tile template
    /// </summary>
    public class ViewActionTileTemplateSelector : DataTemplateSelector 
    {
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var viewAction = item as IViewAction;
            if (viewAction == null) return NormalTileTemplate;

            if (viewAction.ActionView != null) return CustomViewTileTemplate;

            switch (viewAction.Significance)
            {
                case ViewActionSignificance.Normal:
                    return NormalTileTemplate;
                case ViewActionSignificance.BelowNormal:
                case ViewActionSignificance.Lowest:
                    return TinyTileTemplate;
                case ViewActionSignificance.AboveNormal:
                    return WideTileTemplate;
                case ViewActionSignificance.Highest:
                    return WideSquareTileTemplate;
            }

            return NormalTileTemplate;
        }

        /// <summary>
        /// Template for tiny tiles
        /// </summary>
        /// <value>The tiny tile template.</value>
        public DataTemplate TinyTileTemplate { get; set; }

        /// <summary>
        /// Template for normal tiles
        /// </summary>
        /// <value>The tiny tile template.</value>
        public DataTemplate NormalTileTemplate { get; set; }

        /// <summary>
        /// Template for wide tiles
        /// </summary>
        /// <value>The tiny tile template.</value>
        public DataTemplate WideTileTemplate { get; set; }

        /// <summary>
        /// Template for wide square tiles
        /// </summary>
        /// <value>The tiny tile template.</value>
        public DataTemplate WideSquareTileTemplate { get; set; }

        /// <summary>
        /// Template for custom view tiles
        /// </summary>
        /// <value>The tiny tile template.</value>
        public DataTemplate CustomViewTileTemplate { get; set; }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Vapor.Standard
{
    /// <summary>
    /// Interaction logic for LargeImage.xaml
    /// </summary>
    public partial class LargeImage : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeImage"/> class.
        /// </summary>
        public LargeImage()
        {
            InitializeComponent();
        }
    }
}

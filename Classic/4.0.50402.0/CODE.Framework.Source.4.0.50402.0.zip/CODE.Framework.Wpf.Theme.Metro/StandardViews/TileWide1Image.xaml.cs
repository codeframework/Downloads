﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileWide1Image.xaml
    /// </summary>
    public partial class TileWide1Image : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileWide1Image"/> class.
        /// </summary>
        public TileWide1Image()
        {
            InitializeComponent();
        }
    }
}

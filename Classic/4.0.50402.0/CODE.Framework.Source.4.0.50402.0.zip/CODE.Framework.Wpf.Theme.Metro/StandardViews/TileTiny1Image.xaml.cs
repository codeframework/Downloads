﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileTiny1Image.xaml
    /// </summary>
    public partial class TileTiny1Image : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileTiny1Image"/> class.
        /// </summary>
        public TileTiny1Image()
        {
            InitializeComponent();
        }
    }
}

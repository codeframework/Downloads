﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileWide5Images.xaml
    /// </summary>
    public partial class TileWide5Images : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileWide5Images"/> class.
        /// </summary>
        public TileWide5Images()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for PeekImageAndText01.xaml
    /// </summary>
    public partial class PeekImageAndText01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PeekImageAndText01"/> class.
        /// </summary>
        public PeekImageAndText01()
        {
            InitializeComponent();
        }
    }
}

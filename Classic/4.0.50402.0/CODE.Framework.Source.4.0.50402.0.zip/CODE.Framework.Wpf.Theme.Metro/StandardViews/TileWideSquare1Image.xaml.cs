﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileWideSquare1Image.xaml
    /// </summary>
    public partial class TileWideSquare1Image : Grid
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TileWideSquare1Image()
        {
            InitializeComponent();
        }
    }
}

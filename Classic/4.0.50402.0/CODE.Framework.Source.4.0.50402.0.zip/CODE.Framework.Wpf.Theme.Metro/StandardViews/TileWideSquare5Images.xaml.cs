﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileWideSquare5Images.xaml
    /// </summary>
    public partial class TileWideSquare5Images : Grid
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TileWideSquare5Images()
        {
            InitializeComponent();
        }
    }
}

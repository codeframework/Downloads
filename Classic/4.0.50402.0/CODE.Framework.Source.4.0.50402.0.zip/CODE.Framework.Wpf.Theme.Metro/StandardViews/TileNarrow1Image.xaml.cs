﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for TileNarrow1Image.xaml
    /// </summary>
    public partial class TileNarrow1Image : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TileNarrow1Image"/> class.
        /// </summary>
        public TileNarrow1Image()
        {
            InitializeComponent();
        }
    }
}

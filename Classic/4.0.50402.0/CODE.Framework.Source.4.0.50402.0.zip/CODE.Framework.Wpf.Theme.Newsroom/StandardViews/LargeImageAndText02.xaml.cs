﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeImageAndText02.xaml
    /// </summary>
    public partial class LargeImageAndText02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeImageAndText02"/> class.
        /// </summary>
        public LargeImageAndText02()
        {
            InitializeComponent();
        }
    }
}

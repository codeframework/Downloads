﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for PeekImageAndText03.xaml
    /// </summary>
    public partial class PeekImageAndText03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PeekImageAndText03"/> class.
        /// </summary>
        public PeekImageAndText03()
        {
            InitializeComponent();
        }
    }
}

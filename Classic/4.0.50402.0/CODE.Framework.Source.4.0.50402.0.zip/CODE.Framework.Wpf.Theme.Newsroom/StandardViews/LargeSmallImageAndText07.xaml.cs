﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeSmallImageAndText07.xaml
    /// </summary>
    public partial class LargeSmallImageAndText07 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeSmallImageAndText07"/> class.
        /// </summary>
        public LargeSmallImageAndText07()
        {
            InitializeComponent();
        }
    }
}

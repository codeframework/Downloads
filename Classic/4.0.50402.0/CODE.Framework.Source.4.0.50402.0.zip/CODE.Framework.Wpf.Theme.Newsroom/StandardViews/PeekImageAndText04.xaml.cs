﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for PeekImageAndText04.xaml
    /// </summary>
    public partial class PeekImageAndText04 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PeekImageAndText04"/> class.
        /// </summary>
        public PeekImageAndText04()
        {
            InitializeComponent();
        }
    }
}

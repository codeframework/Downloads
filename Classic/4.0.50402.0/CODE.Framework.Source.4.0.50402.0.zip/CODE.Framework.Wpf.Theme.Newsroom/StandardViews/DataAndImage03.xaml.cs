﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for DataAndImage03.xaml
    /// </summary>
    public partial class DataAndImage03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataAndImage03"/> class.
        /// </summary>
        public DataAndImage03()
        {
            InitializeComponent();
        }
    }
}

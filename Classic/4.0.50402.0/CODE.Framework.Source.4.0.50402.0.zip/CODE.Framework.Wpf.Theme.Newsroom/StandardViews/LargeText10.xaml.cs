﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText10.xaml
    /// </summary>
    public partial class LargeText10 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText10"/> class.
        /// </summary>
        public LargeText10()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for Data02.xaml
    /// </summary>
    public partial class Data02 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Data02"/> class.
        /// </summary>
        public Data02()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Newsroom.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeText01.xaml
    /// </summary>
    public partial class LargeText01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeText01"/> class.
        /// </summary>
        public LargeText01()
        {
            InitializeComponent();
        }
    }
}

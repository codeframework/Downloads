﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for DataAndImage01.xaml
    /// </summary>
    public partial class DataAndImage01 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataAndImage01"/> class.
        /// </summary>
        public DataAndImage01()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeImageCollection.xaml
    /// </summary>
    public partial class LargeImageCollection : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeImageCollection"/> class.
        /// </summary>
        public LargeImageCollection()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace CODE.Framework.Wpf.Theme.Metro.StandardViews
{
    /// <summary>
    /// Interaction logic for LargeSmallImageAndText03.xaml
    /// </summary>
    public partial class LargeSmallImageAndText03 : Grid
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LargeSmallImageAndText03"/> class.
        /// </summary>
        public LargeSmallImageAndText03()
        {
            InitializeComponent();
        }
    }
}

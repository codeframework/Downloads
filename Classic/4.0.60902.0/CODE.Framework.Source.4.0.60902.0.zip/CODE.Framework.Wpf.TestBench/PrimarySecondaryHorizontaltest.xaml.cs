﻿using System.Windows;

namespace CODE.Framework.Wpf.TestBench
{
    /// <summary>
    /// Interaction logic for PrimarySecondaryHorizontaltest.xaml
    /// </summary>
    public partial class PrimarySecondaryHorizontalTest : Window
    {
        public PrimarySecondaryHorizontalTest()
        {
            InitializeComponent();
        }
    }
}
